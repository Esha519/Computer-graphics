#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI 3.14159265358979323846
GLfloat i0 = 0.0f;
GLfloat i00 = 0.0f;
GLfloat i000 = 0.0f;

void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}
void display() {


    glClearColor(1.0f, 01.0f, 01.0f, 01.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)
    glLineWidth(5.4);

	int i;

	//GLfloat radius = 0.8f; //radius


	GLfloat x1=0.0f; GLfloat y1=0.0f; GLfloat radius1 =.6f;
	int triangleAmount = 900; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radiu219, 255, 51s
	GLfloat twicePi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(173, 173, 133);
		glVertex2f(x1, y1); // center of circle
		for(i= 0; i <= triangleAmount;i++)
            {
			glVertex2f(
		            x1 + (radius1 * cos(i *  twicePi1 / triangleAmount)),
			    y1 + (radius1 * sin(i * twicePi1 / triangleAmount))
			);
		}
	glEnd();
		int i1;

	//GLfloat radius = 0.8f; //radius


	GLfloat x11=0.0f; GLfloat y11=0.0f; GLfloat radius11 =.035f;
	int triangleAmount11 = 150; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radiu219, 255, 51s
	GLfloat twicePi11 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
		glVertex2f(x1, y1); // center of circle
		for(i= 0; i <= triangleAmount;i++)
            {
			glVertex2f(
		            x11 + (radius11 * cos(i *  twicePi11 / triangleAmount11)),
			    y11 + (radius11* sin(i * twicePi1 / triangleAmount11))
			);
		}
	glEnd();
	glBegin(GL_LINES);

	glColor3ub(0, 0, 0);
	glVertex2f(0.02,0.58);
	glVertex2f(0.02,0.5);
	glEnd();

    glBegin(GL_LINES);

	glColor3ub(0, 0, 0);
	glVertex2f(0.03,0.58);
	glVertex2f(0.03,0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.02,0.58);
	glVertex2f(0.01,0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.02,0.5);
	glVertex2f(0.01,0.58);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.58,0.018);
	glVertex2f(0.52,0.018);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.58,0.0);
	glVertex2f(0.52,0.0);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.58,-0.0180);
	glVertex2f(0.52,-0.018);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.02,-0.58);
	glVertex2f(0.0,-0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.02,-0.58);
	glVertex2f(-0.05,-0.50);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.01,-0.58);
	glVertex2f(0.01,-0.50);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.58,0.02);
	glVertex2f(-0.52,0.060);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.52,0.02);
	glVertex2f(-0.58,0.060);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.58,0.0);
	glVertex2f(-0.52,0.0);
	glEnd();


	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.43,0.32);
	glVertex2f(-0.4,0.40);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.43,0.4);
	glVertex2f(-0.4,0.320);
	glEnd();





	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.24,0.42);
	glVertex2f(-0.270,0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.27,0.42);
	glVertex2f(-0.240,0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.23,0.42);
	glVertex2f(-0.230,0.5);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.23,0.45);
	glVertex2f(0.250,0.53);
	glEnd();

    glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.43,0.3);
	glVertex2f(0.450,0.38);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.42,0.3);
	glVertex2f(0.440,0.38);
	glEnd();


    glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.47,-0.23);
	glVertex2f(0.530,-0.25);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.46,-0.25);
	glVertex2f(0.520,-0.27);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.45,-0.27);
	glVertex2f(0.510,-0.29);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.44,-0.29);
	glVertex2f(0.50,-0.31);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.22,-0.54);
	glVertex2f(0.19,-0.46);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.22,-0.54);
	glVertex2f(0.25,-0.46);
	glEnd();

    glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(0.44,-0.29);
	glVertex2f(0.50,-0.31);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.23,-0.54);
	glVertex2f(-0.20,-0.46);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.23,-0.54);
	glVertex2f(-0.25,-0.45);
	glEnd();

  glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.22,-0.54);
	glVertex2f(-0.19,-0.47);
	glEnd();

      glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.21,-0.55);
	glVertex2f(-0.18,-0.48);
	glEnd();

   glTranslatef(-.24,.18,0);

	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.23,-0.54);
	glVertex2f(-0.20,-0.46);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.23,-0.54);
	glVertex2f(-0.25,-0.45);
	glEnd();

  glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.22,-0.54);
	glVertex2f(-0.19,-0.47);
	glEnd();

      glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.21,-0.55);
	glVertex2f(-0.18,-0.48);
	glEnd();

    glLoadIdentity();


    glBegin(GL_LINES);
	glColor3ub(0, 0, 0);
	glVertex2f(-0.44,-0.38);
	glVertex2f(-0.41,-0.31);
	glEnd();

	glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(i0,0.0,0.0,1.0);

    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.45f, 0.05f);
    glVertex2f( 0.38f, 0.05f);
    glEnd();

    glPopMatrix();//while glPopMatrix pops the top matrix off the stack

    i0+=-0.008715f;


	glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(i00,0.0,0.0,1.0);

    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.33f, 0.05f);
    glVertex2f( 0.22f, 0.05f);
    glEnd();

    glPopMatrix();//while glPopMatrix pops the top matrix off the stack

    i00+=-0.00014525f;

    glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(i000,0.0,0.0,1.0);

    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( -0.13f, 0.15f);
    glVertex2f( -0.1f, 0.15f);
    glEnd();

    glPopMatrix();//while glPopMatrix pops the top matrix off the stack

    i000+=-0.00000240833f;

    glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,-0.7);
	glVertex2f(-0.7,0.7);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,-0.7);
	glVertex2f(0.7,-0.7);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.7,0.7);
	glVertex2f(-0.7,0.7);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.7,0.7);
	glVertex2f(0.7,-0.7);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.65,0.7);
	glVertex2f(0.65,-0.7);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.65,0.7);
	glVertex2f(-0.65,-0.7);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,-0.65);
	glVertex2f(0.7,-0.65);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,0.65);
	glVertex2f(0.7,0.65);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,0.7);
	glVertex2f(-0.7,-0.7);
	glVertex2f(-0.65,-0.7);
	glVertex2f(-0.65,0.7);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(198, 140, 83);
	glVertex2f(0.7,0.7);
	glVertex2f(0.65,0.7);
	glVertex2f(0.65,-0.7);
	glVertex2f(0.7,-0.7);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,0.7);
	glVertex2f(-0.7,0.65);
	glVertex2f(0.7,0.65);
	glVertex2f(0.7,0.7);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,-0.65);
	glVertex2f(-0.7,-.7);
	glVertex2f(0.7,-.7);
	glVertex2f(0.7,-0.65);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,0.54);
	glVertex2f(-0.57,0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,0.5);
	glVertex2f(-0.5495,0.64);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,0.46);
	glVertex2f(-0.525,0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,0.425);
	glVertex2f(-0.5,0.64);
	glEnd();
    glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,-0.54);
	glVertex2f(-0.57,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,-0.5);
	glVertex2f(-0.5495,-0.64);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,-0.46);
	glVertex2f(-0.525,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.645,-0.425);
	glVertex2f(-0.5,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,0.54);
	glVertex2f(0.57,0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,0.5);
	glVertex2f(0.5495,0.64);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,0.46);
	glVertex2f(0.525,0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,0.425);
	glVertex2f(0.5,0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,-0.54);
	glVertex2f(0.57,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,-0.5);
	glVertex2f(0.5495,-0.64);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,-0.46);
	glVertex2f(0.525,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(0.645,-0.425);
	glVertex2f(0.5,-0.64);
	glEnd();
	glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,0.64);
	glVertex2f(0.7,0.64);
	glEnd();
  glBegin(GL_LINES);
	glColor3ub(198, 140, 83);
	glVertex2f(-0.7,-0.64);
	glVertex2f(0.7,-0.64);
	glEnd();



	glFlush();


}



   int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display);

	glutIdleFunc(Idle);
// Register display callback handler for window re-paint
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}

